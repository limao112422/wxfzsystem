$(function(){
	$('.header-nav i').click(function(){
		window.history.back(-1);
	})
})